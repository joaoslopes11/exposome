"""
LIFEXPLORE - EXPOSOME RISK CALCULATOR (v3 - patient-adaptive)
============================================================================
See "Literature_Review_CEI_LifeXplore.docx" for the full literature review
and reference list. Reference keys used in comments below (e.g. [GEMM2018])
point to that list.

Carried over from v2 (real-time geocoding):
  - No hardcoded postal-code map. Each postal code is geocoded in real time
    through Nominatim (OpenStreetMap), with on-disk caching and a
    Zippopotam.us fallback.

New in v3 (scientific model + individualization):
  - Each exposure factor is no longer an arbitrary 0-100 score. It is now a
    RELATIVE RISK (RR) computed from a dose-response function anchored in
    published literature (GBD, WHO, GEMM, Gasparrini et al., Chiuve et
    al./AHEI-2010, etc.) - see REFERENCES below.
  - RRs are combined MULTIPLICATIVELY on top of a baseline hazard specific
    to the patient's AGE and SEX, following the standard methodology used
    in individualized absolute-risk models (Gail model / iCARE / CanRisk /
    proportional Cox regression). Two patients with the SAME environmental
    exposure but different age, sex, or comorbidities no longer get the
    same CEI by construction.
  - The socioeconomic component is no longer generated at random
    (np.random). It is now treated as missing data (NaN) until it is wired
    to a real socioeconomic deprivation source (e.g. Spain's INE/MEDEA
    indices). Filling in fabricated numbers is not scientifically
    acceptable.
  - Every individual RR per component is still exported (not just the
    final composite index), along with an explicit Baseline_Hazard column,
    for transparency and auditability.
  - The final CEI (0-100) is now a population percentile of the raw
    multiplicative risk (Risk_Index = Baseline_Hazard x Prod(RR_i)),
    computed within the processed sample. The raw Risk_Index is exported
    as well, to allow comparisons across different runs/cohorts.

EXPLICIT LIMITATIONS (see section 6 of the review document):
  - The RRs used here are approximations of published dose-response curves
    (mostly log-linear), not the full curves (splines, non-linear GEMM,
    etc.). Suitable for screening/hypothesis generation, not for individual
    clinical decisions without further validation.
  - Baseline_Hazard is a relative shape (Gompertz + sex ratio), NOT
    calibrated against real Galician/Spanish mortality tables.
  - The multiplicative combination assumes conditional independence between
    exposures (a common epidemiological simplification that may not
    capture real interactions, e.g. smoking x air pollution).
============================================================================
"""

import pandas as pd
import numpy as np
import requests
import time
import pickle
import json
import re
import os
import sys
import argparse
import warnings
from datetime import datetime
from collections import defaultdict
from typing import Dict, List, Optional, Tuple, Any

warnings.filterwarnings('ignore')

CURRENT_YEAR = datetime.now().year
np.random.seed(42)

# ============================================================================
# CONFIGURATION
# ============================================================================

ENV_CACHE_FILE = 'exposome_env_cache.pkl'          # weather/air-quality cache
GEOCODE_CACHE_FILE = 'geocode_cache.json'           # persistent geocoding cache

OPENMETEO_ARCHIVE = 'https://archive-api.open-meteo.com/v1/archive'
OPENMETEO_AIR_QUALITY = 'https://air-quality-api.open-meteo.com/v1/air-quality'
NOMINATIM_URL = 'https://nominatim.openstreetmap.org/search'
ZIPPOPOTAM_URL = 'https://api.zippopotam.us/es'     # fallback (Spain)

# Country used for geocoding. Can be overridden from the command line.
DEFAULT_COUNTRY = 'Spain'

# Required by the Nominatim usage policy.
# Replace the email with yours / the project's before running in production.
NOMINATIM_USER_AGENT = 'LifeXplore-ExposomeCalculator/3.0 ([email protected])'

# Nominatim caps requests at 1/second per IP.
NOMINATIM_MIN_INTERVAL_S = 1.05

# ============================================================================
# SCIENTIFIC REFERENCES (see the literature review document for the full
# list with details). Each risk function below cites the corresponding key
# in a comment, for auditability.
# ============================================================================
REFERENCES = {
    'GEMM2018': "Burnett et al. 2018, PNAS 115(38):9592-9597 - Global Exposure Mortality Model (PM2.5)",
    'WHO_AQG2021': "WHO 2021 - Global Air Quality Guidelines (PM2.5 reference = 5 ug/m3)",
    'SMOKE_META2024': "KoGES sex-specific pack-year mortality study, Tob Induc Dis 2024 (HR current 1.90-2.25, former 1.19-2.35)",
    'SMOKE_SEXSTRAT2026': "Sex-stratified cohort analysis, 2026 (HR current smoker 2.37[M]/2.65[F] all-cause mortality)",
    'GBD_ALCOHOL2018': "GBD 2016 Alcohol Collaborators, Lancet 2018;392:1015-1035 (risk-minimizing level is zero)",
    'WOOD2018': "Wood et al. Lancet 2018;391:1513-1523 - alcohol risk thresholds, 599,912 drinkers",
    'WHO_NOISE2018': "WHO Environmental Noise Guidelines (Europe), 2018 - RR 1.08 per 10 dB Lden for IHD",
    'GASPARRINI2015': "Gasparrini et al. Lancet 2015;386:369-375 - heat/cold mortality, 13 countries",
    'CHIUVE2012': "Chiuve et al. J Nutr 2012;142:1009-1018 - AHEI-2010",
    'WHITEHALL_AHEI2017': "Whitehall II cohort, Br J Nutr 2017 - AHEI-2010 HR 0.82/SD, mean 48.7 SD 10.0",
    'SAMITZ2011': "Samitz et al. Int J Epidemiol 2011;40:1382-1400 - physical activity dose-response meta-analysis",
    'UKB_COX2025': "Functional Cox model, UK Biobank, arXiv:2511.04852, 2025 - HR for sex/smoking/comorbidity/Townsend",
    'TOWNSEND1988': "Townsend et al. 1988 - Townsend Deprivation Index",
}

# "Legacy" thresholds kept only for the diet/physical-activity auxiliary
# scoring functions (AHEI-2010 thresholds and MET categories), which remain
# valid as a scoring structure - see review sections 3.6/3.7.
SCIENTIFIC_MODELS = {
    'physicalActivity': {
        'metScores': {'sedentary': (65, 1.3), 'light': (45, 1.1), 'moderate': (30, 0.9),
                     'active': (20, 0.8), 'veryactive': (15, 0.7)},
    },
}


def baseline_hazard(age: float, sex: str) -> float:
    """
    RELATIVE baseline hazard by age/sex (Gompertz shape + sex ratio).

    [UKB_COX2025]: men have an all-cause mortality HR of ~1.518x versus
    women, age-adjusted, in a UK Biobank cohort (age >= 50).

    IMPORTANT: this is a relative shape, not an absolute event probability.
    For a clinically certified absolute risk score, this function should be
    replaced with age/sex-specific incidence or mortality rates published
    by Spain's INE/INE-Galicia or by the GBD for Spain (the same logic used
    in iCARE/CanRisk - see review, section 4).
    """
    if pd.isna(age):
        age = 45
    age = max(20, min(100, float(age)))
    # Gompertz-like: relative hazard roughly doubles every ~9 years above 40
    age_component = np.exp(0.075 * (age - 40))
    sex_mult = 1.518 if validate_sex(sex) == 'male' else 1.0  # UKB_COX2025
    return age_component * sex_mult

# ============================================================================
# REAL-TIME GEOCODING (replaces a hardcoded postal-code map)
# ============================================================================

class Geocoder:
    """
    Geocodes postal codes in real time via Nominatim (OpenStreetMap), with
    on-disk caching and a Zippopotam.us fallback.

    On-disk caching = efficiency: each postal code is requested from the
    API at most once (even across different runs of the script).
    """

    def __init__(self, country: str = DEFAULT_COUNTRY, cache_file: str = GEOCODE_CACHE_FILE):
        self.country = country
        self.cache_file = cache_file
        self.cache: Dict[str, Dict[str, Any]] = self._load_cache()
        self.session = requests.Session()
        self.session.headers.update({'User-Agent': NOMINATIM_USER_AGENT})
        self._last_request_ts = 0.0

    # -- persistent on-disk cache --------------------------------------------
    def _load_cache(self) -> Dict[str, Dict[str, Any]]:
        if os.path.exists(self.cache_file):
            try:
                with open(self.cache_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception:
                return {}
        return {}

    def _save_cache(self) -> None:
        try:
            with open(self.cache_file, 'w', encoding='utf-8') as f:
                json.dump(self.cache, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"    Warning: could not write the geocoding cache: {e}")

    # -- rate limiting (required by the Nominatim usage policy) -------------
    def _throttle(self) -> None:
        elapsed = time.time() - self._last_request_ts
        if elapsed < NOMINATIM_MIN_INTERVAL_S:
            time.sleep(NOMINATIM_MIN_INTERVAL_S - elapsed)
        self._last_request_ts = time.time()

    # -- urban/suburban/rural classification from the OSM response ----------
    @staticmethod
    def _classify_location_type(result: Dict[str, Any]) -> str:
        address = result.get('address', {}) or {}
        addresstype = (result.get('addresstype') or result.get('type') or '').lower()
        osm_class = (result.get('class') or '').lower()

        if 'city' in address or addresstype in ('city', 'city_district', 'municipality'):
            return 'urban'
        if 'suburb' in address or addresstype == 'suburb':
            return 'urban'
        if 'town' in address or addresstype == 'town':
            return 'suburban'
        if 'village' in address or addresstype in ('village', 'hamlet'):
            return 'rural'
        if osm_class in ('place',) and addresstype in ('isolated_dwelling', 'farm'):
            return 'rural'
        return 'mixed'

    # -- Nominatim (primary source) ------------------------------------------
    def _geocode_nominatim(self, postal_code: str) -> Optional[Tuple[float, float, str]]:
        params = {
            'postalcode': postal_code,
            'country': self.country,
            'format': 'jsonv2',
            'addressdetails': 1,
            'limit': 1,
        }
        try:
            self._throttle()
            resp = self.session.get(NOMINATIM_URL, params=params, timeout=15)
            if resp.status_code != 200:
                return None
            data = resp.json()
            if not data:
                return None
            top = data[0]
            lat, lon = float(top['lat']), float(top['lon'])
            loc_type = self._classify_location_type(top)
            return (lat, lon, loc_type)
        except Exception:
            return None

    # -- Zippopotam.us (lighter fallback, no location-type classification) --
    def _geocode_zippopotam(self, postal_code: str) -> Optional[Tuple[float, float, str]]:
        try:
            resp = self.session.get(f"{ZIPPOPOTAM_URL}/{postal_code}", timeout=10)
            if resp.status_code != 200:
                return None
            data = resp.json()
            places = data.get('places', [])
            if not places:
                return None
            lat = float(places[0]['latitude'])
            lon = float(places[0]['longitude'])
            return (lat, lon, 'mixed')  # zippopotam does not return a location type
        except Exception:
            return None

    # -- public entry point --------------------------------------------------
    def geocode(self, postal_code: str) -> Tuple[float, float, str]:
        """Returns (lat, lon, location_type) for a postal code, using
        cache -> Nominatim -> Zippopotam -> None (failure recorded)."""
        key = str(postal_code).strip()

        if key in self.cache:
            entry = self.cache[key]
            return (entry['lat'], entry['lon'], entry['location_type'])

        result = self._geocode_nominatim(key)
        source = 'nominatim'

        if result is None:
            result = self._geocode_zippopotam(key)
            source = 'zippopotam'

        if result is None:
            # No valid coordinates: marked as NaN instead of fabricating a
            # location (avoids biasing the environmental risk components).
            self.cache[key] = {'lat': None, 'lon': None, 'location_type': None, 'source': 'failed'}
            self._save_cache()
            return (np.nan, np.nan, 'unknown')

        lat, lon, loc_type = result
        self.cache[key] = {'lat': lat, 'lon': lon, 'location_type': loc_type, 'source': source}
        self._save_cache()
        return (lat, lon, loc_type)

    def geocode_many(self, postal_codes: List[str]) -> Dict[str, Tuple[float, float, str]]:
        """Geocodes a list of UNIQUE postal codes, printing progress."""
        out = {}
        unique_codes = sorted(set(str(p).strip() for p in postal_codes if pd.notna(p)))
        print(f"\n[1/3] Geocoding {len(unique_codes)} unique postal codes (real-time, Nominatim)...")
        for i, code in enumerate(unique_codes):
            was_cached = code in self.cache
            lat, lon, loc_type = self.geocode(code)
            tag = "(cache)" if was_cached else "(API)"
            status = f"({lat:.4f}, {lon:.4f}) [{loc_type}]" if not pd.isna(lat) else "FAILED"
            print(f"  {i+1}/{len(unique_codes)} {code} -> {status} {tag}")
            out[code] = (lat, lon, loc_type)
        return out


def safe_get(row: pd.Series, key: str, default: Any = None) -> Any:
    if key in row.index:
        return row.get(key, default)
    return default

# ============================================================================
# VALIDATION HELPERS (unchanged from v2)
# ============================================================================

def validate_sex(value: Any) -> str:
    if pd.isna(value) or value is None:
        return 'female'
    v = str(value).lower().strip()
    if v in ['male', 'm', '1', 'hombre']:
        return 'male'
    if v in ['female', 'f', '2', 'mujer']:
        return 'female'
    return 'female'

def validate_age(value: Any) -> float:
    if pd.isna(value) or value is None:
        return np.nan
    try:
        if isinstance(value, str):
            nums = re.findall(r'\d+', value)
            if not nums:
                return np.nan
            age = int(nums[0])
        else:
            age = int(float(value))
        if age < 0 or age > 120:
            return np.nan
        return age
    except Exception:
        return np.nan

def validate_smoking_status(value: Any) -> str:
    if pd.isna(value) or value is None:
        return 'never'
    v = str(value).strip().replace('.0', '')
    mapping = {'1': 'current_heavy', '2': 'current_light', '3': 'former', '4': 'never', '5': 'never'}
    return mapping.get(v, 'never')

def validate_secondhand_smoke(value: Any) -> str:
    if pd.isna(value) or value is None:
        return 'none'
    v = str(value).strip().replace('.0', '')
    mapping = {'1': 'occasional', '2': 'frequent', '3': 'daily', '4': 'occasional', '5': 'occasional', '6': 'none'}
    return mapping.get(v, 'none')

def validate_alcohol_frequency(value: Any) -> str:
    if pd.isna(value) or value is None:
        return 'never'
    v = str(value).strip().replace('.0', '')
    mapping = {'1': 'daily', '2': '5_6_days', '3': '3_4_days', '4': '1_2_days', '5': '2_3_month',
               '6': 'once_month', '7': 'less_month', '8': 'former', '9': 'never', '10': 'never', '11': 'never'}
    return mapping.get(v, 'never')

def validate_diet_frequency(value: Any) -> float:
    if pd.isna(value) or value is None:
        return 0.0
    v = str(value).strip().replace('.0', '')
    mapping = {'1': 0.03, '2': 0.066, '3': 0.14, '4': 0.43, '5': 1.0, '6': 2.5, '7': 4.0}
    return mapping.get(v, 0.0)

def determine_activity_level(row: pd.Series) -> str:
    deporte_tempo = safe_get(row, 'deporte_tempo', 0)
    deporte_semana = safe_get(row, 'deporte_semana', 0)
    try:
        if pd.isna(deporte_tempo) or pd.isna(deporte_semana):
            met_min = 0
        else:
            met_min = float(deporte_tempo) * float(deporte_semana) * 4
    except Exception:
        met_min = 0
    if met_min >= 600:
        return 'veryactive'
    elif met_min >= 300:
        return 'active'
    elif met_min >= 150:
        return 'moderate'
    elif met_min >= 60:
        return 'light'
    else:
        return 'sedentary'

# ============================================================================
# DIET
# ============================================================================

def calculate_diet_score(row: pd.Series) -> Tuple[float, float]:
    """Returns (risk_score_0_100, ahei_total_0_110). ahei_total follows the
    11-component structure of AHEI-2010 [CHIUVE2012], needed to calibrate
    the RR against the Whitehall II cohort [WHITEHALL_AHEI2017]."""
    def get_avg(items):
        vals = [validate_diet_frequency(safe_get(row, item, 0)) for item in items]
        return sum(vals) / len(vals) if vals else 0

    def score_component(avg, max_val, inverse=False):
        if avg == 0:
            return 10 if inverse else 0
        if inverse:
            return max(0, min(10, 10 - (avg / max_val) * 10))
        return max(0, min(10, (avg / max_val) * 10))

    veg_avg = get_avg(['brocoli', 'zanahoria', 'espinacas', 'tomate', 'ensalada'])
    fruit_avg = get_avg(['manzana', 'naranja', 'platano', 'rojos'])
    whole_avg = get_avg(['pan_integral']) * 30
    sugary_avg = get_avg(['refrescos'])
    nut_avg = get_avg(['frutos_secos'])
    meat_avg = get_avg(['carne', 'cerdo', 'hamburguesa_1', 'embutidos'])
    trans_avg = get_avg(['mantequilla', 'bolleria', 'galletas'])
    fish_avg = get_avg(['pescado', 'otros_pescados'])
    aceite = validate_diet_frequency(safe_get(row, 'aceite', 0))
    sodium_avg = get_avg(['embutidos'])

    sex = validate_sex(safe_get(row, 'sexo', '2'))
    wine_avg = get_avg(['vino'])
    beer_avg = get_avg(['cerveza'])
    alcohol_drinks = wine_avg + beer_avg

    veg_score = score_component(veg_avg, 5.0)
    fruit_score = score_component(fruit_avg, 4.0)
    whole_score = score_component(whole_avg, 75.0)
    sugary_score = score_component(sugary_avg, 1.0, inverse=True)
    nut_score = score_component(nut_avg, 1.0)
    meat_score = score_component(meat_avg, 0.5, inverse=True)
    trans_score = score_component(trans_avg, 0.5, inverse=True)
    omega_mg = fish_avg * 200
    omega_score = score_component(omega_mg, 250.0)
    pufa_score = score_component(aceite, 2.0)
    sodium_score = score_component(sodium_avg, 0.5, inverse=True)

    max_moderate = 1.5 if sex == 'female' else 2.0
    if alcohol_drinks == 0:
        alcohol_score = 0
    elif 0.5 <= alcohol_drinks <= max_moderate:
        alcohol_score = 10
    else:
        alcohol_score = max(0, min(10, 10 - abs(alcohol_drinks - max_moderate) * 5))

    scores = [veg_score, fruit_score, whole_score, sugary_score, nut_score,
              meat_score, trans_score, omega_score, pufa_score, sodium_score, alcohol_score]
    scores = [max(0, min(10, s)) for s in scores]
    ahei_total = sum(scores)

    risk = 100 - (ahei_total / 1.1)
    if aceite > 0:
        risk *= (1 - (aceite * 0.02))

    risk = max(0, min(100, round(risk, 1)))
    return risk, round(ahei_total, 1)

# ============================================================================
# PHYSICAL ACTIVITY
# ============================================================================

def calculate_physical_activity_score(row: pd.Series) -> float:
    """Legacy 0-100 score (kept for reference/compatibility only).
    See calculate_physical_activity_rr() for the version used in the v3 model."""
    model = SCIENTIFIC_MODELS['physicalActivity']
    activity_level = determine_activity_level(row)
    score, mult = model['metScores'].get(activity_level, (45, 1.1))
    risk = score * mult

    imc = safe_get(row, 'imc', 25)
    try:
        imc_val = float(imc)
        if imc_val >= 30:
            risk *= 1.2
        elif imc_val >= 25:
            risk *= 1.05
    except Exception:
        pass

    grip_strength = safe_get(row, 'valor_absoluto', 0)
    try:
        grip_val = float(grip_strength)
        sex = validate_sex(safe_get(row, 'sexo', '2'))
        if sex == 'male' and grip_val < 27:
            risk *= 1.3
        elif sex == 'female' and grip_val < 16:
            risk *= 1.3
    except Exception:
        pass

    strength_days = safe_get(row, 'atividad_esp', 0)
    if not pd.isna(strength_days) and strength_days >= 2:
        risk *= 0.85

    return min(100, max(0, round(risk, 1)))


def calculate_physical_activity_rr(row: pd.Series) -> float:
    """
    Mortality RR by physical activity level vs. sedentary behaviour (RR=1.0).

    [SAMITZ2011]: meta-analysis of 80 cohorts (>1.3M participants) - pooled
    RR ~0.86 for 150 min/week of moderate-to-vigorous activity and ~0.74 for
    300 min/week, with a ~9% risk reduction per additional weekly hour of
    vigorous exercise (RR 0.91/hour).
    """
    activity_level = determine_activity_level(row)
    base_rr = {'sedentary': 1.00, 'light': 0.95, 'moderate': 0.86, 'active': 0.79, 'veryactive': 0.65}
    rr = base_rr.get(activity_level, 1.0)

    imc = safe_get(row, 'imc', 25)
    try:
        imc_val = float(imc)
        if imc_val >= 30:
            rr *= 1.15
        elif imc_val >= 25:
            rr *= 1.05
    except Exception:
        pass

    grip_strength = safe_get(row, 'valor_absoluto', 0)
    try:
        grip_val = float(grip_strength)
        sex = validate_sex(safe_get(row, 'sexo', '2'))
        if sex == 'male' and grip_val < 27:
            rr *= 1.15
        elif sex == 'female' and grip_val < 16:
            rr *= 1.15
    except Exception:
        pass

    strength_days = safe_get(row, 'atividad_esp', 0)
    if not pd.isna(strength_days) and strength_days >= 2:
        rr *= 0.93

    return round(max(0.3, rr), 3)

# ============================================================================
# HEALTH / COMORBIDITIES
# ============================================================================

def calculate_health_score(row: pd.Series) -> float:
    """Legacy 0-100 score. The per-condition weights are the ones
    originally defined by the LifeXplore clinical team; they were NOT
    recalibrated against published hazard ratios because the
    lista_enfermedad___N codes currently have no public codebook linking
    them to specific diagnoses. The relative ordering of the weights was
    kept as a proxy for clinical severity. See calculate_health_rr()."""
    risk = 0
    condition_weights = {
        'lista_enfermedad___1': 8, 'lista_enfermedad___2': 15, 'lista_enfermedad___3': 15,
        'lista_enfermedad___4': 15, 'lista_enfermedad___10': 10, 'lista_enfermedad___11': 15,
        'lista_enfermedad___12': 20, 'lista_enfermedad___13': 10, 'lista_enfermedad___15': 5,
        'lista_enfermedad___20': 8, 'lista_enfermedad___21': 5, 'lista_enfermedad___23': 20,
        'lista_enfermedad___26': 25, 'lista_enfermedad___27': 8, 'lista_enfermedad___28': 8,
        'lista_enfermedad___29': 10, 'lista_enfermedad___33': 20, 'lista_enfermedad___34': 20,
        'lista_enfermedad___35': 15, 'lista_enfermedad___36': 15, 'lista_enfermedad___37': 10,
        'lista_enfermedad___39': 10, 'lista_enfermedad___40': 10
    }
    for col, weight in condition_weights.items():
        if col in row.index and row.get(col, 0) == 1:
            risk += weight

    med_weights = {
        'lista_medicamentos___5': 5, 'lista_medicamentos___6': 10, 'lista_medicamentos___13': 8,
        'lista_medicamentos___18': 5, 'lista_medicamentos___19': 10, 'lista_medicamentos___23': 8,
        'lista_medicamentos___25': 12, 'lista_medicamentos___26': 8
    }
    for col, weight in med_weights.items():
        if col in row.index and row.get(col, 0) == 1:
            risk += weight

    if safe_get(row, 'lista_medicamentos___4', 0) == 1:
        qual_med = str(safe_get(row, 'qual_medicamento', '')).lower()
        if 'probiotic' in qual_med or 'probiotico' in qual_med:
            risk -= 5

    imc = safe_get(row, 'imc', 25)
    try:
        imc_val = float(imc)
        if imc_val >= 30:
            risk += 10
        elif imc_val >= 25:
            risk += 5
    except Exception:
        pass

    return max(0, min(100, round(risk, 1)))


def calculate_health_rr(row: pd.Series) -> Tuple[float, float]:
    """
    Converts the legacy comorbidity score (0-100) into an approximate RR.

    [UKB_COX2025]: mortality HR ~2.40 for a prior cancer diagnosis and
    ~1.35 for coronary heart disease, in a UK Biobank cohort. RR = exp(k *
    score) with k=0.035, calibrated so that the maximum weight assigned to
    a single severe condition on the legacy scale (25 points) lands near
    the published cancer HR order of magnitude (exp(0.035*25)=2.36). This
    is a coarse ORDER-OF-MAGNITUDE calibration, not a 1:1 per-diagnosis
    mapping - replace with a Charlson/Elixhauser-style index with a
    condition-specific HR once an official codebook for the
    lista_enfermedad___N codes becomes available.
    """
    score = calculate_health_score(row)
    k = 0.035
    rr = float(np.exp(k * score))
    return round(rr, 3), score

# ============================================================================
# SOCIOECONOMIC STATUS
# ============================================================================

def calculate_socioeconomic_rr(deprivation_index: float) -> float:
    """
    RR derived from a REAL socioeconomic deprivation index (not randomly
    generated - see the note in the script header).

    [UKB_COX2025]/[TOWNSEND1988]: a 2.6% increase in mortality risk per
    additional unit of the Townsend Deprivation Index
    (RR ~ 1.026^units).

    Returns NaN if no real deprivation source is wired into the pipeline
    (intentional behaviour: reporting the value as missing is preferable
    to fabricating it). To wire in real data, see the
    DeprivationIndexProvider class below.
    """
    if pd.isna(deprivation_index):
        return np.nan
    return round(float(1.026 ** deprivation_index), 3)


class DeprivationIndexProvider:
    """
    Stub for connecting a REAL socioeconomic deprivation source by postal
    code / municipality (e.g. Spain's INE household income distribution
    atlas, or the MEDEA index used in Spanish public-health studies). By
    default it returns NaN for every postal code.

    To activate: replace the body of `get(postal_code)` with a real lookup
    (API call, local INE CSV, etc.) that returns a numeric deprivation
    index on a scale comparable to the Townsend Deprivation Index (higher
    = more deprived). Without that connection, the socioeconomic component
    of the CEI is correctly flagged as missing data instead of being
    fabricated.
    """

    def __init__(self, source_csv: Optional[str] = None):
        self._data = {}
        if source_csv and os.path.exists(source_csv):
            try:
                df_dep = pd.read_csv(source_csv, dtype=str)
                # Expected columns: codigo_postal, deprivation_index
                for _, r in df_dep.iterrows():
                    self._data[str(r['codigo_postal']).strip()] = float(r['deprivation_index'])
                print(f"    Deprivation index loaded from {source_csv} ({len(self._data)} postal codes)")
            except Exception as e:
                print(f"    Warning: could not load {source_csv}: {e}")

    def get(self, postal_code: str) -> float:
        return self._data.get(str(postal_code).strip(), np.nan)

# ============================================================================
# API CLIENT (weather and air quality - Open-Meteo, real time)
# ============================================================================

class EnvAPIClient:
    def __init__(self, cache_file: str = ENV_CACHE_FILE):
        self.cache_file = cache_file
        self._cache = self._load_cache()
        self.session = requests.Session()

    def _load_cache(self) -> Dict:
        if os.path.exists(self.cache_file):
            try:
                with open(self.cache_file, 'rb') as f:
                    return pickle.load(f)
            except Exception:
                return {}
        return {}

    def save_cache(self) -> None:
        with open(self.cache_file, 'wb') as f:
            pickle.dump(self._cache, f)

    def fetch_historical_weather(self, lat: float, lon: float, birth_year: int) -> List[Dict]:
        if pd.isna(lat) or pd.isna(lon):
            return []
        cache_key = f"weather_{lat:.4f}_{lon:.4f}_{birth_year}"
        if cache_key in self._cache:
            return self._cache[cache_key]

        weather_data = []
        end_year = CURRENT_YEAR - 1
        start_year = max(1940, int(birth_year))

        if start_year <= end_year:
            for year in range(start_year, end_year + 1, 10):
                chunk_end = min(year + 9, end_year)
                try:
                    params = {
                        'latitude': lat, 'longitude': lon,
                        'start_date': f"{year}-01-01", 'end_date': f"{chunk_end}-12-31",
                        'daily': 'temperature_2m_max,temperature_2m_min', 'timezone': 'auto'
                    }
                    response = self.session.get(OPENMETEO_ARCHIVE, params=params, timeout=20)
                    if response.status_code == 200:
                        data = response.json()
                        if 'daily' in data and data['daily']:
                            yearly_temps = defaultdict(list)
                            dates = data['daily'].get('time', [])
                            max_temps = data['daily'].get('temperature_2m_max', [])
                            min_temps = data['daily'].get('temperature_2m_min', [])
                            for i, date in enumerate(dates):
                                if i < len(max_temps) and i < len(min_temps):
                                    y = int(date[:4])
                                    if max_temps[i] is not None:
                                        yearly_temps[y].append(max_temps[i])
                                    if min_temps[i] is not None:
                                        yearly_temps[y].append(min_temps[i])
                            for y, temps in yearly_temps.items():
                                if temps:
                                    avg_temp = sum(temps) / len(temps)
                                    weather_data.append({
                                        'year': y,
                                        'heat_wave_days': max(0, int((avg_temp - 25) * 2)) if avg_temp > 25 else 0,
                                        'extreme_heat_days': max(0, int(avg_temp - 30)) if avg_temp > 30 else 0,
                                        'cold_wave_days': max(0, int(0 - avg_temp)) if avg_temp < 0 else 0,
                                        'avg_temp': round(avg_temp, 1)
                                    })
                    time.sleep(0.2)
                except Exception:
                    continue

        self._cache[cache_key] = sorted(weather_data, key=lambda x: x['year'])
        return self._cache[cache_key]

    def fetch_historical_air_quality(self, lat: float, lon: float, birth_year: int) -> List[Dict]:
        if pd.isna(lat) or pd.isna(lon):
            return []
        cache_key = f"air_{lat:.4f}_{lon:.4f}_{birth_year}"
        if cache_key in self._cache:
            return self._cache[cache_key]

        air_data = []
        start_year = max(2022, int(birth_year))
        end_year = CURRENT_YEAR - 1

        if start_year <= end_year:
            try:
                params = {
                    'latitude': lat, 'longitude': lon,
                    'start_date': f"{start_year}-01-01", 'end_date': f"{end_year}-12-31",
                    'hourly': 'pm10,pm2_5', 'timezone': 'auto'
                }
                response = self.session.get(OPENMETEO_AIR_QUALITY, params=params, timeout=20)
                if response.status_code == 200:
                    data = response.json()
                    if 'hourly' in data and data['hourly'].get('pm2_5'):
                        pm25_values = data['hourly']['pm2_5']
                        dates = data['hourly'].get('time', [])
                        yearly_pm25 = defaultdict(list)
                        for i, date in enumerate(dates):
                            if i < len(pm25_values) and pm25_values[i] is not None:
                                year = int(date[:4])
                                yearly_pm25[year].append(pm25_values[i])
                        for year, values in yearly_pm25.items():
                            if values:
                                air_data.append({'year': year, 'pm25': round(sum(values) / len(values), 1)})
                time.sleep(0.2)
            except Exception:
                pass

        self._cache[cache_key] = sorted(air_data, key=lambda x: x['year'])
        return self._cache[cache_key]

    @staticmethod
    def estimate_noise(location_type: str) -> float:
        base_noise = {'urban': 55, 'suburban': 45, 'industrial': 60, 'rural': 30, 'mixed': 40, 'unknown': np.nan}
        return base_noise.get(location_type, np.nan)

# ============================================================================
# RISK CALCULATOR
# ============================================================================

class RiskCalculator:
    """
    Each method returns a RELATIVE RISK (RR), not an arbitrary 0-100 score.
    RR=1.0 is always the reference value ("no excess risk relative to
    minimal/no exposure"). RR>1 increases individual risk; RR<1 reduces it
    (e.g. protective physical activity). NaN means "missing data" and is
    excluded from the multiplicative combination (never treated as RR=1
    nor as zero risk).
    """

    # ---- Air pollution ------------------------------------------------------
    @staticmethod
    def air_pollution_rr(air_data: List[Dict], birth_year: int, age: float) -> float:
        """
        Log-linear RR approximating the shape of GEMM [GEMM2018], with a 5
        ug/m3 reference [WHO_AQG2021], attenuated by age (the GEMM hazard
        ratio decreases with age - documented qualitatively in [GEMM2018]).
        """
        if not air_data:
            return np.nan
        lifetime = [d for d in air_data if birth_year <= d['year'] <= CURRENT_YEAR - 1]
        if not lifetime:
            return np.nan
        avg_pm25 = sum(d['pm25'] for d in lifetime) / len(lifetime)
        beta = 0.0089  # log-linear approximation of the GEMM/WHO slope at low concentrations
        rr_raw = np.exp(beta * max(0, avg_pm25 - 5))

        age_val = 45 if pd.isna(age) else float(age)
        attenuation = max(0.4, 1 - 0.006 * max(0, age_val - 40))  # approximate age attenuation
        rr = 1 + (rr_raw - 1) * attenuation
        return round(max(0.5, min(3.0, rr)), 3)

    # ---- Smoking --------------------------------------------------------------
    @staticmethod
    def smoking_rr(row: pd.Series) -> float:
        """
        RR anchored to published HRs: former smoker ~1.19-1.31, light
        smoker ~1.9, heavy smoker ~2.55 [SMOKE_META2024, SMOKE_SEXSTRAT2026],
        modulated by secondhand smoke exposure and scaled by cumulative
        pack-years.
        """
        smoking_status = validate_smoking_status(safe_get(row, 'fuma', '4'))
        secondhand = validate_secondhand_smoke(safe_get(row, 'tabaco_cerrado', '6'))

        base_rr = {
            'never': 1.00, 'former': 1.19, 'current_light': 1.90,
            'current_moderate': 2.20, 'current_heavy': 2.55,
        }
        rr = base_rr.get(smoking_status, 1.0)

        secondhand_mult = {'none': 1.00, 'occasional': 1.03, 'frequent': 1.06, 'daily': 1.10}
        rr *= secondhand_mult.get(secondhand, 1.0)

        if smoking_status in ('current_heavy', 'current_light', 'current_moderate'):
            nr_cigarillos = safe_get(row, 'nr_cigarillos', 0)
            anos_fumar = safe_get(row, 'anos_fumar', 0)
            try:
                if not pd.isna(nr_cigarillos) and not pd.isna(anos_fumar):
                    pack_years = (float(nr_cigarillos) / 20) * float(anos_fumar)
                    rr *= (1 + 0.01 * min(pack_years, 60))  # capped cumulative-dose scaling
            except Exception:
                pass

        return round(max(0.8, min(6.0, rr)), 3)

    # ---- Alcohol ----------------------------------------------------------------
    @staticmethod
    def alcohol_rr(row: pd.Series) -> float:
        """
        RR increasing monotonically from zero consumption (no "bonus" for
        moderate drinking), consistent with [GBD_ALCOHOL2018]/[WOOD2018]:
        the level that minimizes overall health risk is zero. Category
        mapped to approximate grams of alcohol/week (10g = 1 WHO standard
        drink).
        """
        alcohol_freq = validate_alcohol_frequency(safe_get(row, 'alcool', '9'))
        grams_week = {
            'never': 0, 'former': 0, 'less_month': 20, 'once_month': 40,
            '2_3_month': 60, '1_2_days': 120, '3_4_days': 250,
            '5_6_days': 400, 'daily': 560,
        }
        g = grams_week.get(alcohol_freq, 0)
        rr = np.exp(0.0006 * g)  # coarse log-linear approximation of the GBD 2018 slope
        return round(max(1.0, min(3.0, rr)), 3)

    # ---- Noise --------------------------------------------------------------
    @staticmethod
    def noise_rr(lden_estimate: float) -> float:
        """
        RR = 1.08^((Lden-53)/10), applied only above the WHO reference
        threshold (~53 dB Lden) [WHO_NOISE2018]. lden_estimate is an
        approximation derived from the location type (urban/suburban/rural)
        returned by geocoding - replace with real noise maps (e.g. Spain's
        Environmental Noise Directive / SICA data) once available.
        """
        if pd.isna(lden_estimate):
            return np.nan
        threshold = 53.0
        if lden_estimate <= threshold:
            return 1.0
        rr = 1.08 ** ((lden_estimate - threshold) / 10.0)
        return round(min(2.0, rr), 3)

    # ---- Temperature --------------------------------------------------------
    @staticmethod
    def temperature_rr(weather_data: List[Dict], birth_year: int) -> float:
        """
        [GASPARRINI2015]: moderate cold contributes MORE to
        temperature-attributable mortality than heat, in temperate climates
        (such as Galicia). Weights are inverted relative to v2 to reflect
        this; the linear-to-RR transform is a coarse, documented
        approximation.
        """
        if not weather_data:
            return np.nan
        lifetime = [d for d in weather_data if birth_year <= d['year'] <= CURRENT_YEAR - 1]
        if not lifetime:
            return np.nan
        avg_heat = sum(d.get('heat_wave_days', 0) for d in lifetime) / len(lifetime)
        avg_extreme = sum(d.get('extreme_heat_days', 0) for d in lifetime) / len(lifetime)
        avg_cold = sum(d.get('cold_wave_days', 0) for d in lifetime) / len(lifetime)
        score = avg_cold * 0.8 + avg_heat * 0.35 + avg_extreme * 0.55
        rr = 1 + score / 100.0
        return round(max(0.8, min(2.0, rr)), 3)

    # ---- Diet -----------------------------------------------------------------
    @staticmethod
    def diet_rr(row: pd.Series) -> Tuple[float, float, float]:
        """
        RR calibrated directly against the Whitehall II cohort
        [WHITEHALL_AHEI2017]: mortality HR = 0.82 per standard deviation of
        AHEI-2010 (mean 48.7, SD 10.0). Returns (rr, legacy_risk_score,
        ahei_total).
        """
        risk_score, ahei_total = calculate_diet_score(row)
        z = (ahei_total - 48.7) / 10.0
        rr = 0.82 ** z
        return round(max(0.4, min(2.5, rr)), 3), risk_score, ahei_total

    # ---- Physical activity ------------------------------------------------------
    @staticmethod
    def physical_activity_rr(row: pd.Series) -> float:
        return calculate_physical_activity_rr(row)

    # ---- Health / comorbidities --------------------------------------------
    @staticmethod
    def health_rr(row: pd.Series) -> Tuple[float, float]:
        return calculate_health_rr(row)

    # ---- Socioeconomic status -----------------------------------------------
    @staticmethod
    def socioeconomic_rr(deprivation_index: float) -> float:
        return calculate_socioeconomic_rr(deprivation_index)

    # ---- Multiplicative combination (patient-adaptive) -----------------------
    @staticmethod
    def individual_risk(age: float, sex: str, rr_components: Dict[str, float]) -> Tuple[float, float, Dict[str, float]]:
        """
        Individual risk = Baseline_Hazard(age, sex) x Prod(valid RR_i).

        Standard methodology for individualized absolute-risk models (Gail
        model / iCARE / CanRisk / proportional Cox regression) - see
        literature review, sections 4-5. Missing components (NaN) are
        EXCLUDED from the combination (never treated as RR=1, which would
        be an implicit assumption rather than an absence of recorded
        information).
        """
        h0 = baseline_hazard(age, sex)
        valid = {k: v for k, v in rr_components.items() if not pd.isna(v)}
        product = h0
        for v in valid.values():
            product *= v
        return product, h0, valid

# ============================================================================
# MAIN PROCESSING
# ============================================================================

def process_exposome_risks(input_file: str, output_folder: Optional[str] = None,
                            sample_limit: Optional[int] = None,
                            country: str = DEFAULT_COUNTRY,
                            deprivation_csv: Optional[str] = None) -> pd.DataFrame:
    print("=" * 80)
    print(" LIFEXPLORE - EXPOSOME RISK CALCULATOR (v3 - patient-adaptive)")
    print(" Real-time geocoding (Nominatim/OSM) - no hardcoded maps")
    print(" Individual risks = literature-anchored multiplicative RRs,")
    print(" combined on top of an age/sex-specific baseline hazard")
    print(" See Literature_Review_CEI_LifeXplore.docx for full references")
    print("=" * 80)

    if output_folder is None:
        output_folder = os.path.dirname(input_file) or '.'
    os.makedirs(output_folder, exist_ok=True)

    try:
        df = pd.read_csv(input_file, encoding='utf-8-sig')
    except Exception:
        try:
            df = pd.read_csv(input_file, encoding='latin-1')
        except Exception:
            df = pd.read_csv(input_file, encoding='utf-8')

    print(f"\nLoaded {len(df)} samples")

    if sample_limit and sample_limit < len(df):
        df = df.head(sample_limit)
        print(f"Limited to {sample_limit} samples")

    if 'codigo_postal' not in df.columns:
        raise ValueError("The input file has no 'codigo_postal' column.")

    run_id_col = 'record_id' if 'record_id' in df.columns else df.columns[0]
    print(f"Using '{run_id_col}' as identifier")

    # Normalize postal codes to strings without decimal points (e.g. 36201.0 -> "36201")
    def norm_postal(v):
        if pd.isna(v):
            return None
        try:
            return str(int(float(v)))
        except Exception:
            return str(v).strip()

    df['_postal_norm'] = df['codigo_postal'].apply(norm_postal)
    postal_codes = df['_postal_norm'].dropna().unique().tolist()
    print(f"{len(postal_codes)} unique postal codes")

    # ------------------------------------------------------------------
    # [1/3] Real-time geocoding (replaces a hardcoded map)
    # ------------------------------------------------------------------
    geocoder = Geocoder(country=country)
    geo_cache = geocoder.geocode_many(postal_codes)

    n_failed = sum(1 for lat, _, _ in geo_cache.values() if pd.isna(lat))
    if n_failed:
        print(f"  Warning: {n_failed} postal code(s) could not be geocoded (left as NaN in the environmental variables)")

    # ------------------------------------------------------------------
    # [2/3] Real environmental data (Open-Meteo) per unique coordinate
    # ------------------------------------------------------------------
    print("\n[2/3] Fetching environmental data from Open-Meteo...")
    env_client = EnvAPIClient()
    env_data = {}
    deprivation_provider = DeprivationIndexProvider(source_csv=deprivation_csv)
    if deprivation_csv is None:
        print("  Note: no socioeconomic deprivation source was provided (--deprivation-csv). "
              "The 'Socioeconomic' component will be NaN rather than fabricated - see the "
              "DeprivationIndexProvider class to wire in real data (e.g. INE/MEDEA).")

    unique_coords = {}
    for postal, (lat, lon, loc_type) in geo_cache.items():
        if pd.isna(lat):
            continue
        key = f"{lat:.4f}_{lon:.4f}"
        if key not in unique_coords:
            unique_coords[key] = (lat, lon, loc_type, postal)

    for i, (key, (lat, lon, loc_type, postal)) in enumerate(unique_coords.items()):
        print(f"\n  {i+1}/{len(unique_coords)}: {postal} ({lat:.4f}, {lon:.4f}) [{loc_type}]")

        ages = df[df['_postal_norm'] == postal]['edad'].dropna()
        min_birth = CURRENT_YEAR - int(ages.max()) if len(ages) > 0 else 1980

        print(f"    Weather ({min_birth}-{CURRENT_YEAR-1})...", end=" ")
        weather = env_client.fetch_historical_weather(lat, lon, min_birth)
        print(f"{len(weather)} years")

        print(f"    Air Quality (2022-{CURRENT_YEAR-1})...", end=" ")
        air_data = env_client.fetch_historical_air_quality(lat, lon, min_birth)
        print(f"{len(air_data)} years")

        noise_level = env_client.estimate_noise(loc_type)
        print(f"    Noise (Lden proxy): {noise_level} dB")

        env_data[key] = {
            'weather': weather, 'air': air_data, 'noise': noise_level,
            'location_type': loc_type, 'postal': postal,
        }
        env_client.save_cache()

    # ------------------------------------------------------------------
    # [3/3] Calculate INDIVIDUAL risks (multiplicative RRs, age/sex)
    # ------------------------------------------------------------------
    print("\n[3/3] Calculating patient-adaptive risks...")
    results = []

    for idx, row in df.iterrows():
        try:
            postal = row['_postal_norm']
            lat, lon, loc_type = geo_cache.get(postal, (np.nan, np.nan, 'unknown'))
            key = f"{lat:.4f}_{lon:.4f}" if not pd.isna(lat) else "unknown"

            env = env_data.get(key, {'weather': [], 'air': [], 'noise': np.nan, 'location_type': loc_type})

            age = validate_age(safe_get(row, 'edad', 45))
            sex = validate_sex(safe_get(row, 'sexo', '2'))
            birth_year = CURRENT_YEAR - age if not pd.isna(age) else 1980
            deprivation_idx = deprivation_provider.get(postal)

            diet_rr, diet_score_legacy, ahei_total = RiskCalculator.diet_rr(row)
            health_rr, health_score_legacy = RiskCalculator.health_rr(row)

            rr_components = {
                'AirPollution': RiskCalculator.air_pollution_rr(env.get('air', []), birth_year, age),
                'Smoking': RiskCalculator.smoking_rr(row),
                'Alcohol': RiskCalculator.alcohol_rr(row),
                'Noise': RiskCalculator.noise_rr(env.get('noise', np.nan)),
                'Temperature': RiskCalculator.temperature_rr(env.get('weather', []), birth_year),
                'Diet': diet_rr,
                'PhysicalActivity': RiskCalculator.physical_activity_rr(row),
                'Health': health_rr,
                'Socioeconomic': RiskCalculator.socioeconomic_rr(deprivation_idx),
            }

            risk_index, h0, valid_rrs = RiskCalculator.individual_risk(age, sex, rr_components)
            n_missing = len(rr_components) - len(valid_rrs)

            results.append({
                'Risk_Index': risk_index,
                'Baseline_Hazard': round(h0, 3),
                'RR_Air_Pollution': rr_components['AirPollution'],
                'RR_Smoking': rr_components['Smoking'],
                'RR_Alcohol': rr_components['Alcohol'],
                'RR_Noise': rr_components['Noise'],
                'RR_Temperature': rr_components['Temperature'],
                'RR_Diet': rr_components['Diet'],
                'RR_Physical_Activity': rr_components['PhysicalActivity'],
                'RR_Health': rr_components['Health'],
                'RR_Socioeconomic': rr_components['Socioeconomic'],
                'AHEI_Total': ahei_total,
                'N_Components_Missing': n_missing,
                'Age_Used': age,
                'Sex_Used': sex,
                'Latitude': lat,
                'Longitude': lon,
                'Location_Type': loc_type,
            })

        except Exception as e:
            print(f"  Error processing {row.get(run_id_col, idx)}: {e}")
            results.append({})

        if (idx + 1) % 25 == 0:
            print(f"  Processed {idx + 1}/{len(df)}")

    # ------------------------------------------------------------------
    # Merge, population-level CEI (percentile) and output
    # ------------------------------------------------------------------
    print("\nSaving results...")

    risk_columns = ['Risk_Index', 'Baseline_Hazard', 'RR_Air_Pollution', 'RR_Smoking', 'RR_Alcohol',
                     'RR_Noise', 'RR_Temperature', 'RR_Diet', 'RR_Physical_Activity', 'RR_Health',
                     'RR_Socioeconomic', 'AHEI_Total', 'N_Components_Missing', 'Age_Used', 'Sex_Used',
                     'Latitude', 'Longitude', 'Location_Type']

    for col in risk_columns:
        df[col] = [r.get(col, np.nan) for r in results]

    # CEI (0-100): population percentile of the raw Risk_Index WITHIN this
    # sample. It is a score relative to the processed cohort - not directly
    # comparable across runs with different samples (for that, use the raw
    # Risk_Index column instead). See literature review, section 4.
    valid_risk = df['Risk_Index'].dropna()
    if len(valid_risk) > 1:
        df['CEI'] = df['Risk_Index'].rank(pct=True) * 100
        df.loc[df['Risk_Index'].isna(), 'CEI'] = np.nan
        df['CEI'] = df['CEI'].round(1)
    else:
        df['CEI'] = np.nan

    risk_columns = ['CEI'] + risk_columns
    df.drop(columns=['_postal_norm'], inplace=True)

    base_name = os.path.splitext(os.path.basename(input_file))[0]

    output_cols = [run_id_col] + [c for c in risk_columns if c in df.columns and c != run_id_col]
    cei_output = df[output_cols]
    cei_path = os.path.join(output_folder, f'{base_name}_exposome_cei.csv')
    cei_output.to_csv(cei_path, index=False, encoding='utf-8-sig')
    print(f"\nResults saved: {cei_path}")

    excel_path = os.path.join(output_folder, f'{base_name}_exposome_complete.xlsx')
    df.to_excel(excel_path, index=False)
    print(f"Excel file saved: {excel_path}")

    # Summary statistics
    print("\n" + "=" * 80)
    print("GEOCODING SUMMARY")
    print("=" * 80)
    geo_types = {}
    for postal, (lat, lon, loc_type) in geo_cache.items():
        geo_types[loc_type] = geo_types.get(loc_type, 0) + 1
    print(f"Total postal codes: {len(geo_cache)}")
    for loc_type, count in geo_types.items():
        print(f"  {loc_type}: {count}")

    print("\n" + "=" * 80)
    print("CEI SUMMARY")
    print("=" * 80)
    print(f"Total samples: {len(df)}")

    if 'CEI' in df.columns:
        valid_cei = df['CEI'].dropna()
        if len(valid_cei) > 0:
            print(f"Average CEI: {valid_cei.mean():.2f}")
            print(f"CEI range: [{valid_cei.min():.1f} - {valid_cei.max():.1f}]")
            print(f"Valid CEI samples: {len(valid_cei)}/{len(df)}")
        else:
            print("No valid CEI scores")

    print("\nRisk statistics (non-NaN):")
    for col in risk_columns:
        if col in df.columns and df[col].dtype.kind in 'fi':
            valid = df[col].dropna()
            if len(valid) > 0:
                print(f"  {col}: n={len(valid)}, mean={valid.mean():.1f}, min={valid.min():.1f}, max={valid.max():.1f}")
            else:
                print(f"  {col}: no valid data")

    print(f"\nOutput folder: {output_folder}")
    print("=" * 80)

    return df


def main():
    parser = argparse.ArgumentParser(description="LifeXplore Exposome Risk Calculator (real-time geocoding)")
    parser.add_argument('input_file', nargs='?', default='LifeXplore_DATA_2026-07-03_1429.csv',
                         help="Input CSV file (LifeXplore/REDCap export)")
    parser.add_argument('--output', '-o', default='./exposome_results', help="Output folder")
    parser.add_argument('--limit', '-n', type=int, default=None, help="Limit to N samples (debug)")
    parser.add_argument('--country', '-c', default=DEFAULT_COUNTRY, help="Country used for geocoding (e.g. Spain)")
    parser.add_argument('--deprivation-csv', default=None,
                         help="Optional CSV with columns 'codigo_postal,deprivation_index' for the "
                              "socioeconomic component (see DeprivationIndexProvider). Without it, "
                              "the component is left as NaN.")
    args = parser.parse_args()

    if not os.path.exists(args.input_file):
        print(f"File not found: {args.input_file}")
        sys.exit(1)

    results = process_exposome_risks(
        input_file=args.input_file,
        output_folder=args.output,
        sample_limit=args.limit,
        country=args.country,
        deprivation_csv=args.deprivation_csv,
    )

    print("\nSample results:")
    display_cols = ['record_id', 'CEI', 'Risk_Index', 'Age_Used', 'Sex_Used', 'RR_Air_Pollution',
                     'RR_Smoking', 'RR_Alcohol', 'RR_Diet', 'Location_Type']
    available = [c for c in display_cols if c in results.columns]
    if available:
        print(results[available].head(10).to_string(index=False))


if __name__ == "__main__":
    main()
